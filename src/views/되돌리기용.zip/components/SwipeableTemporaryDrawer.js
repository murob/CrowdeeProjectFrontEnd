import React from 'react';
import clsx from 'clsx';
import { makeStyles } from '@material-ui/core/styles';
import SwipeableDrawer from '@material-ui/core/SwipeableDrawer';
import Button from '@material-ui/core/Button';
import List from '@material-ui/core/List';
import Divider from '@material-ui/core/Divider';
import ListItem from '@material-ui/core/ListItem';
import ListItemIcon from '@material-ui/core/ListItemIcon';
import ListItemText from '@material-ui/core/ListItemText';
import InboxIcon from '@material-ui/icons/MoveToInbox';
import MailIcon from '@material-ui/icons/Mail';
import { Link } from "react-router-dom";
import { useEffect, useState } from "react";
import BackerAdmin from './BackerAdmin';
const useStyles = makeStyles({
  list: {
    width: 250,
  },
  fullList: {
    width: 'auto',
  },
});


export default function SwipeableTemporaryDrawer() {
  const [members, setMembers] = useState([])

    // useEffect(() => {
    //   fetch('http://localhost:8081/admin/findMemberAll')
    //   .then(res => res.json())
    //   .then((res) => {
    //   // console.log("씨발쫌넘어ㅏ오세요",res)
    //   console.log("아래")
    //   console.log(res)
    //   console.log("위")
    //   if(!res.status==200){
    //     console.log("혹시 여기왔니?")
    //     throw new Error('http 오류');
    //   }
    // })
      // return res.json()})
  //     .then((res)=> {
  //     setMembers(createData(res));
        
  //     })
  //     .catch((e) =>{
  //       alert("게시물 조회 중 에러발생 "+ e.message);
  //     })
  // },[]);

  const classes = useStyles(
      
  );
  const [state, setState] = React.useState({
    top: false,
    left: false,
    bottom: false,
    right: false,
  });

  const toggleDrawer = (anchor, open) => (event) => {
    if (event && event.type === 'keydown' && (event.key === 'Tab' || event.key === 'Shift')) {
      return;
    }

    setState({ ...state, [anchor]: open });
  };

  const list = (anchor) => (
    <div
      className={clsx(classes.list, {
        [classes.fullList]: anchor === 'top' || anchor === 'bottom',
      })}
      role="presentation"
      onClick={toggleDrawer(anchor, false)}
      onKeyDown={toggleDrawer(anchor, false)}
    >
      <List>
        <ListItem>
        {/* {members.map((member) => (
        <Link to={{
          pathname: `/admin-member`,
            state: { 
                memberId: member.memberId,
                password: member.password,
                userName: member.userName
              }
          }}>
             회원관리씨발
        </Link>
        ))}  */}
       
            <Link to="/admin-backer">backer관리</Link> 
        </ListItem>
        <ListItem>
            <Link to="/admin-creater">ceater관리</Link>
        </ListItem>
        <ListItem>
            <Link to="/admin-creater-inspection">ceater전환관리</Link>
        </ListItem>
        <ListItem>
            <Link to="/admin-funding">펀딩관리</Link>
        </ListItem>
        {/* <ListItem>
            <Link to="/admin-backerView">backer상세보기관리</Link>
        </ListItem> */}
      </List>
      <Divider/>
    </div>
  );
  return (
    <div classe>
      {['MENU'].map((anchor) => (
        <React.Fragment key={anchor}>
          <Button onClick={toggleDrawer(anchor, true)}>{anchor}</Button>
          <SwipeableDrawer
            anchor={anchor}
            open={state[anchor]}
            onClose={toggleDrawer(anchor, false)}
            onOpen={toggleDrawer(anchor, true)}
          >
            {list(anchor)}
          </SwipeableDrawer>
        </React.Fragment>
      ))}
    </div>
  );
}