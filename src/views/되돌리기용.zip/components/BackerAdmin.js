import * as React from 'react';
import { DataGrid } from '@material-ui/data-grid';
import MenuAppBar from './MenuAppBar';
import { useEffect, useState } from "react";
import GetData from './GetData';
import BackerView from './BackerView';
import { Button } from '@material-ui/core';
// import FundingAdmin from "views/AdminPage/components/";
// import React, { useEffect } from 'react';

// const rows = [
//   {id : '12', password: 'fdf1' ,
//                          userName:'fdf2',nickName:'fdf3',
//                          mobile:'fdf4',  email:'fdf5', 
//                          emailCert:'fdf6', registDate:'fdf7', 
//                          secessionDate:'fdf8', userState:'fdf9',
//                          authorities:'fdf10'}
// ];
// var viewList = []
// const column = [
//   {
//     field: 'selectid',
//     headerName: '',
//     type: 'number',
//     width: 90 }
// ]



function createData(list) {
  var tempList = []
  for(var i in list){
    // console.log(list[i].nickName)
    tempList.push({id : list[i].memberId, 
      userName : list[i].userName, 
        email : list[i].email, 
       registDate : list[i].registDate, 
      authorities : list[i].authorities});
    // tempList.push({id : list[i].memberId, password : list[i].password,
    //               userName : list[i].userName, nickNamee : list[i].nickName,
    //               mobile : list[i].mobile,  email : list[i].email, 
    //               emailCert : list[i].emailCert, registDate : list[i].registDate, 
    //               secessionDate : list[i].secessionDate, userState : list[i].userState,
    //               authorities : list[i].authorities});
    // tempList.push({kakaka:list[i].funding_id,password:list[i].funding_id, 
    //   userName: list[i].category, nickName: list[i].goalFundraising, mobile :list[i].restDate, 
    //   email: list[i].title})
  }
  // console.log(tempList[1])
  return tempList;

}

function backerView(list) {
  var tempList = []
  for(var i in list){
    // console.log(list[i].nickName)
    tempList.push({id : list[i].memberId, 
      userName : list[i].userName, 
        email : list[i].email, 
       registDate : list[i].registDate, 
      authority : list[i].authority,
      status : list[i].status});
    // tempList.push({id : list[i].memberId, password : list[i].password,
    //               userName : list[i].userName, nickNamee : list[i].nickName,
    //               mobile : list[i].mobile,  email : list[i].email, 
    //               emailCert : list[i].emailCert, registDate : list[i].registDate, 
    //               secessionDate : list[i].secessionDate, userState : list[i].userState,
    //               authorities : list[i].authorities});
    // tempList.push({kakaka:list[i].funding_id,password:list[i].funding_id, 
    //   userName: list[i].category, nickName: list[i].goalFundraising, mobile :list[i].restDate, 
    //   email: list[i].title})
  }
  // console.log(tempList[1])
  return tempList;

}


function judgeView(list) {
  var tempList = []
  for(var i in list){
    tempList.push({id : list[i].memberId, 
      userName : list[i].userName, 
        email : list[i].email, 
       registDate : list[i].registDate, 
      authorities : list[i].authorities});
  }
  return tempList;

}

  function backerSelect(e,params) {
    e.preventDefault();
    window.location.href = "/admin-backerView/"+params.id;
  }
  

  // function judgeView(e,params) {
  //   e.preventDefault();
  //   window.location.href = "/admin-backer/"+params.id;
  // }
  
  // { id: 1, lastName: 'Snow', firstName: 'Jon', age: 35 },
  export default function BackerAdmin() {

    const [rows,setRows] = React.useState([])

    const columns = [
      {
        field: 'id',
        headerName: 'id',
        type: 'number',
        width: 90 },
      {
        field: 'userName',
        headerName: 'userName',
        width: 150,
        type: 'text',
        editable: true,
      },
      //   valueGetter: (params) =>
      //     `${params.getValue(params.id, 'firstName') || ''} ${
      //       params.getValue(params.id, 'lastName') || ''
      //     }`,
      {
          field: 'email',
          headerName: 'email',
          type: 'text',
          width: 120,
          editable: true,
        },
        {
          field: 'registDate',
          headerName: 'registDate',
          type: 'text',
          width: 200,
          editable: true,
        },
        {
          field: 'authority',
          headerName: 'authority',
          type: 'text',
          width: 150,
          editable: true,
        },
        {
          field: 'status',
          headerName: 'status',
          type: 'text',
          width: 150,
          editable: true,
        },
        {
          field: 'button',
          headerName: '상세보기',
          type: 'button',
          width: 150,
          editable: true,
          renderCell : (params) => (
            <Button
              variant="contained"
              color="primary"
              size="small"
              style={{marginLeft:16}}
              onClick={(e) => {backerSelect(e, params)}}
            >상세보기</Button>
          )
        },
    ];

    //전체 멤버
    useEffect(() => {
        fetch('http://localhost:8081/admin/backer')
        .then(res => res.json())
        .then((res) => {
          console.log("아래")
          console.log(res)
          console.log("위")
          if(!res.status==200){
                console.log("혹시 여기왔니?")
                throw new Error('http 오류');
              }
              setRows(backerView(res));
            // rows.push(createData(res[i].funding_id, res[i].category, res[i].goalFundraising, res[i].restDate, res[i].title, res[i].summery));
               if (res.success) {
          }
        })
      }, []);

      //백커 필터걸기
      // useEffect(() => {
      //   fetch('http://localhost:8081/admin/backer')
      //   .then(res => res.json())
      //   .then((res) => {
      //     console.log("아래")
      //     console.log(res)
      //     console.log("위")
      //     if(!res.status==200){
      //           console.log("혹시 여기왔니?")
      //           throw new Error('http 오류');
      //         }
      //         setRows(backerView(res));
      //       // rows.push(createData(res[i].funding_id, res[i].category, res[i].goalFundraising, res[i].restDate, res[i].title, res[i].summery));
      //          if (res.success) {
      //     }
      //   })
      // }, []);

      //크리에이터 필터걸기
      // useEffect(() => {
      //   fetch('http://localhost:8081/admin/creater')
      //   .then(res => res.json())
      //   .then((res) => {
      //     console.log("아래")
      //     console.log(res)
      //     console.log("위")
      //     if(!res.status==200){
      //           console.log("혹시 여기왔니?")
      //           throw new Error('http 오류');
      //         }
      //         setRows(createrView(res));
      //       // rows.push(createData(res[i].funding_id, res[i].category, res[i].goalFundraising, res[i].restDate, res[i].title, res[i].summery));
      //           if (res.success) {
      //     }
      //   })
      // }, []);
// }
//         // userName:props.userName,nickName:props.nickName,
// mobile:props.mobile,  email:props.email, 
// emailCert:props.emailCert, registDate:props.registDate, 
// secessionDate:props.secessionDate, userState:props.userState,
// authorities:props.authorities,}
    return (
        <div>
             <MenuAppBar></MenuAppBar>
             <h2>상세페이지</h2>
             <Button
              variant="contained"
              color="primary"
              size="small"
              style={{marginLeft:16}}
              onClick={(e) => {backerView(e, params)}}
            >backer</Button>
              <Button
              variant="contained"
              color="primary"
              size="small"
              style={{marginLeft:16}}
              onClick={(e) => {createrView(e, params)}}
            >creater</Button>
              <Button
              variant="contained"
              color="primary"
              size="small"
              style={{marginLeft:16}}
              onClick={(e) => {judgeView(e, params)}}
            >backer->creater심사중</Button>
             <div style={{ height: 800, width: '100%' }}>
             <DataGrid
                rows={rows}
                columns={columns}
                pageSize={10}
                checkboxSelection
                disableSelectionOnClick
                />
            </div>
            
        
        </div>
    )

}