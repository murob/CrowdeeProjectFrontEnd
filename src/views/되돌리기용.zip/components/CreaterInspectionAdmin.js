import * as React from 'react';
import { DataGrid } from '@material-ui/data-grid';
import MenuAppBar from './MenuAppBar';
import { useEffect, useState } from "react";
import { Button } from '@material-ui/core';


function createData(list) {
  var tempList = []
  for(var i in list){
    tempList.push({id : list[i].memberId, 
      Business_number : list[i].businessNumber, 
      Account_number : list[i].accountNumber, 
      Bank_book_image_url : list[i].bankBookImageUrl, 
      Bank_name : list[i].bankName, 
      creator_nick_name : list[i].creatorNickName, 
      status : list[i].status});
  }
  return tempList;
}
//명칭이랑 맵핑 등등 바꾸고, 승인으로 바꾸는로직을 줘야댐
//재로딩해가지공
function createOk(e,params) {
  e.preventDefault();
  window.location.href = "/admin-creater-Ok/"+params.id;
}

function createNo(e,params) {
  e.preventDefault();
  window.location.href = "/admin-creater-No/"+params.id;
}

  export default function CreaterInspectionAdmin() {

    const [rows,setRows] = React.useState([])

    const columns = [
      {
        field: 'id',
        headerName: 'Creatorid',
        type: 'number',
        width: 90 ,
      },
      {
        field: 'Business_number',
        headerName: 'Business_number',
        width: 150,
        type: 'text',
        editable: true,
      },
      {
          field: 'Account_number',
          headerName: 'Account_number',
          type: 'text',
          width: 120,
          editable: true,
        },
        {
          field: 'Bank_book_image_url',
          headerName: 'Bank_book_image_url',
          type: 'text',
          width: 200,
          editable: true,
        },
        {
          field: 'Bank_name',
          headerName: 'Bank_name',
          type: 'text',
          width: 150,
          editable: true,
        },
        {
          field: 'creator_nick_name',
          headerName: 'creator_nick_name',
          type: 'text',
          width: 150,
          editable: true,
        },
        {
          field: 'status',
          headerName: 'status',
          type: 'text',
          width: 150,
          editable: true,
        },
        {
          field: 'button',
          headerName: '승인',
          type: 'button',
          width: 150,
          editable: true,
          renderCell : (params) => (
            <Button
              variant="contained"
              color="primary"
              size="small"
              style={{marginLeft:16}}
              onClick={(e) => {createOk(e, params)}}
            >승인</Button>
          )
        },
        {
          field: 'button2',
          headerName: '거절',
          type: 'button',
          width: 150,
          editable: true,
          renderCell : (params) => (
            <Button
              variant="contained"
              color="primary"
              size="small"
              style={{marginLeft:16}}
              onClick={(e) => {createNo(e, params)}}
            >거절</Button>
          )
        },
    ];

    useEffect(() => {
        fetch('http://localhost:8081/admin/findInspectionCreator')
        .then(res => res.json())
        .then((res) => {
          console.log("아래")
          console.log(res)
          console.log("위")
          if(!res.status==200){
                console.log("혹시 여기왔니?")
                throw new Error('http 오류');
              }
              setRows(createData(res));
               if (res.success) {
          }
        })
      }, []);
    return (
        <div>
             <MenuAppBar></MenuAppBar>
             <div style={{ height: 800, width: '100%' }}>
             <DataGrid
                rows={rows}
                columns={columns}
                pageSize={10}
                checkboxSelection
                disableSelectionOnClick
                />
            </div>
        </div>
    )

}