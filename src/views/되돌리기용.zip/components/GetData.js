// import * as React from 'react';
// import MemberAdmin from './MemberAdmin';
// import { useEffect, useState } from "react";

// export default function GetData() {
//     const [members, setMembers] = useState([]);
//     useEffect(() => {
//     fetch("http://localhost:8081/admin/findMemberAll")
//     .then((res)=>{
//       console.log("씨발쫌넘어ㅏ오세요",res)
//       if(!res.status==200){
//         throw new Error('http 오류');
//       }
//       return res.json()})
//       .then((res)=>{
//       setMembers(res);
//       console.log(res[0].nickName);
       
//       })
//       .catch((e) =>{
//         alert("게시물 조회 중 에러발생 "+ e.message);
//       });
//   },[])
//   //함수 실행시 최초 한번 실행되는 것
 
//   //     const rows = [
//         //         {id: memberNumber[i].memberId, password:memberNumber[i].password ,
//         //              userName:memberNumber[i].userName,nickName:memberNumber[i].nickName,
//         //              mobile:memberNumber[i].mobile,  email:memberNumber[i].email, 
//         //              emailCert:memberNumber[i].emailCert, registDate:memberNumber[i].registDate, 
//         //              secessionDate:memberNumber[i].secessionDate, userState:memberNumber[i].userState,
//         //              authorities:memberNumber[i].authorities,}
//         //     ];
//     return (
//         <div>
//             <MemberAdmin
//                 //   memberId={res[0].memberId}
//                 //   password={res[0].password}
//                 //   userName={res[0].userName}
//                 //   summery={res[0].summery}
//                 //   nickName={member.nickName}
//                 //   email={member.email}
//                 //   emailCert={member.emailCert}
//                 //   registDate={member.registDate}
//             ></MemberAdmin>
//  <GridContainer justify="center">
//               {fundings.map((funding) => (
//                 <FundingCard 
//                   id={funding.funding_id}
//                   title={funding.title}
//                   imgUrl={funding.thumbNailUrl}
//                   summary={funding.summery}
//                   restDate={funding.restDate}
//                   category={funding.category}
//                   goalFundraising={funding.goalFundraising}
//                   ROA={funding.rateOfAchievement}
//                 ></FundingCard>
//               ))} 
//             {members.map((member) => (
//                 <MemberAdmin 
//                     memberId={member.memberId}
//                     password={member.password}
//                     userName={member.userName}
//                     summery={member.summery}
//                     nickName={member.nickName}
//                     email={member.email}
//                     emailCert={member.emailCert}
//                     registDate={member.registDate}
//                 ></MemberAdmin>
//                 {members.map((member) => (
//                     <Link to{{

//                     }} 
//                         memberId={member.memberId}
//                         password={member.password}
//                         userName={member.userName}
//                         summery={member.summery}
//                         nickName={member.nickName}
//                         email={member.email}
//                         emailCert={member.emailCert}
//                         registDate={member.registDate}
//                     ></MemberAdmin>
            
//           </div>
   
//     )
// }