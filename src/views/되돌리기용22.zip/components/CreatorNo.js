import * as React from 'react';
import { DataGrid } from '@material-ui/data-grid';
import MenuAppBar from './MenuAppBar';
import { useEffect, useState } from "react";
import GetData from './GetData';
import { Button } from '@material-ui/core';

function createData(list) {
  var tempList = []
  for(var i in list){
    tempList.push({id : list[i].memberId, 
      Business_number : list[i].businessNumber, 
      Account_number : list[i].accountNumber, 
      Bank_book_image_url : list[i].bankBookImageUrl, 
      Bank_name : list[i].bankName, 
      creator_nick_name : list[i].creatorNickName, 
      status : list[i].status});
  }
  return tempList;

}

function createDataNo(e,params) {
  e.preventDefault();
  window.location.href = "/admin-creator-inspection";
}

  
  export default function CreateNo() {

    const [rows,setRows] = React.useState([])
    const viewId = window.location.pathname.substring(window.location.pathname.lastIndexOf("/") + 1)

    const columns = [
      {
        field: 'id',
        headerName: 'Creatorid',
        type: 'number',
        width: 90 ,
      },
      {
        field: 'Business_number',
        headerName: 'Business_number',
        width: 150,
        type: 'text',
        editable: true,
      },
      {
          field: 'Account_number',
          headerName: 'Account_number',
          type: 'text',
          width: 120,
          editable: true,
        },
        {
          field: 'Bank_book_image_url',
          headerName: 'Bank_book_image_url',
          type: 'text',
          width: 200,
          editable: true,
        },
        {
          field: 'Bank_name',
          headerName: 'Bank_name',
          type: 'text',
          width: 150,
          editable: true,
        },
        {
          field: 'creator_nick_name',
          headerName: 'creator_nick_name',
          type: 'text',
          width: 150,
          editable: true,
        },
        {
          field: 'status',
          headerName: 'status',
          type: 'text',
          width: 150,
          editable: true,
        },
        {
          field: 'button',
          headerName: '확인',
          type: 'button',
          width: 150,
          editable: true,
          renderCell : (params) => (
            <Button
              variant="contained"
              color="primary"
              size="small"
              style={{marginLeft:16}}
              onClick={(e) => {createDataNo(e, params)}}
            >확인</Button>
          )
        },
    ];

    useEffect(() => {
        fetch('http://localhost:8081/admin/creatorNo/'+viewId)
        .then(res => res.json())
        .then((res) => {
          console.log("아래")
          console.log(res)
          console.log("위")
          if(!res.status==200){
                console.log("혹시 여기왔니?")
                throw new Error('http 오류');
              }
              setRows(createData(res));
               if (res.success) {
          }
        })
      }, []);
    return (
        <div>
             <MenuAppBar></MenuAppBar>
             <div style={{ height: 800, width: '100%' }}>
             <h2>심사결과</h2>
             <DataGrid
                rows={rows}
                columns={columns}
                pageSize={10}
                checkboxSelection
                disableSelectionOnClick
                />
            </div>
        </div>
    )

}