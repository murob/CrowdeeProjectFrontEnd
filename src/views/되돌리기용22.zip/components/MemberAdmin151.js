import * as React from 'react';
import { DataGrid } from '@material-ui/data-grid';
import MenuAppBar from './MenuAppBar';
import { useEffect, useState } from "react";
import GetData from './GetData';

const rows = [
  {kakaka : 12, password: 'fdf1' ,
                         userName:'fdf2',nickName:'fdf3',
                         mobile:'fdf4',  email:'fdf5', 
                         emailCert:'fdf6', registDate:'fdf7', 
                         secessionDate:'fdf8', userState:'fdf9',
                         authorities:'fdf10'}
];

function createData(list) {
  var tempList = []
  for(var i in list){
    tempList.push({kakaka:list[i].funding_id,password:list[i].funding_id, 
      userName: list[i].category, nickName: list[i].goalFundraising, mobile :list[i].restDate, 
      email: list[i].title})
  }
  return tempList;
}

const columns = [
    { field: 'Id', headerName: 'Id', width: 90 },
    {
      field: 'password',
      headerName: 'password',
      width: 140,
      type: 'text',
      editable: true,
    },
    {
      field: 'userName',
      headerName: 'userName',
      width: 150,
      type: 'text',
      editable: true,
    },
    {
      field: 'nickName',
      headerName: 'nickName',
      width: 150,
      type: 'text',
      editable: true,
    },
    {
      field: 'mobile',
      headerName: 'mobile',
      type: 'number',
      description: 'This column has a value getter and is not sortable.',
      sortable: false,
      width: 140,
    //   valueGetter: (params) =>
    //     `${params.getValue(params.id, 'firstName') || ''} ${
    //       params.getValue(params.id, 'lastName') || ''
    //     }`,
    },
    {
        field: 'email',
        headerName: 'email',
        type: 'text',
        width: 120,
        editable: true,
      },
      {
        field: 'emailCert',
        headerName: 'emailCert',
        type: 'text',
        width: 140,
        editable: true,
      },
      {
        field: 'registDate',
        headerName: 'registDate',
        type: 'text',
        width: 150,
        editable: true,
      },
      {
        field: 'secessionDate',
        headerName: 'secessionDate',
        type: 'text',
        width: 160,
        editable: true,
      },
      {
        field: 'userState',
        headerName: 'userState',
        type: 'text',
        width: 140,
        editable: true,
      },
      {
        field: 'authorities',
        headerName: 'authorities',
        type: 'text',
        width: 150,
        editable: true,
      },
  ];
 // { id: 1, lastName: 'Snow', firstName: 'Jon', age: 35 },
  export default function MemberAdmin() {
    // const [rows,setRows] = React.useState([])

    useEffect(() => {
        fetch('http://localhost:8081/contents')
        .then(res => res.json())
        .then((res) => {
          console.log("아래")
          console.log(res)
          setRows(createData(res));
            // rows.push(createData(res[i].funding_id, res[i].category, res[i].goalFundraising, res[i].restDate, res[i].title, res[i].summery));
               if (res.success) {
          }
        })
      }, []);
    
// {id: props.memberId, password:props.password ,

// }
//         // userName:props.userName,nickName:props.nickName,
// mobile:props.mobile,  email:props.email, 
// emailCert:props.emailCert, registDate:props.registDate, 
// secessionDate:props.secessionDate, userState:props.userState,
// authorities:props.authorities,}
    return (
        <div>
            
             <MenuAppBar>{회원님의상세페이지}</MenuAppBar>
             <h2></h2>
             <div style={{ height: 800, width: '100%' }}>
             <DataGrid
                rows={rows}
                columns={columns}
                pageSize={10}
                checkboxSelection
                disableSelectionOnClick
                />
            </div>
             {}
            
        
        </div>
    )

}