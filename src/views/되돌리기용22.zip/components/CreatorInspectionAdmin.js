import * as React from 'react';
import { DataGrid } from '@material-ui/data-grid';
import MenuAppBar from './MenuAppBar';
import { useEffect, useState } from "react";
import { Button } from '@material-ui/core';


function createData(list) {
  var tempList = []
  for(var i in list){
    tempList.push(
      {id : list[i].creatorId, 
      Business_number : list[i].businessNumber, 
      Account_number : list[i].accountNumber, 
      Bank_book_image_url : list[i].bankBookImageUrl, 
      Bank_name : list[i].bankName, 
      creator_nickname : list[i].creatorNickName, 
      status : list[i].status
      }
    );
  }
  return tempList;
}


  export default function CreaterInspectionAdmin() {
    
    const [rows,setRows] = React.useState([])

    function creatorOk(e, params) {
      e.preventDefault();
      changeConfirm(params.id)
      alert("승인되었습니다.");
    }

    function creatorNo(e,params) {
      e.preventDefault();
      changereject(params.id)
          alert("승인 거절되었습니다.");
    }
      

    const columns = [
      {
        field: 'id',
        headerName: 'Creatorid',
        type: 'number',
        width: 150 ,
      },
      {
        field: 'Business_number',
        headerName: 'Business_number',
        width: 180,
        type: 'text',
        editable: true,
      },
      {
          field: 'Account_number',
          headerName: 'Account_number',
          type: 'text',
          width: 180,
          editable: true,
        },
        {
          field: 'Bank_book_image_url',
          headerName: 'Bank_book_image_url',
          type: 'text',
          width: 200,
          editable: true,
        },
        {
          field: 'Bank_name',
          headerName: 'Bank_name',
          type: 'text',
          width: 140,
          editable: true,
        },
        {
          field: 'creator_nickname',
          headerName: 'creator_nickname',
          type: 'text',
          width: 170,
          editable: true,
        },
        {
          field: 'status',
          headerName: 'status',
          type: 'text',
          width: 150,
          editable: true,
        },
        {
          field: 'button',
          headerName: '승인',
          type: 'button',
          width: 120,
          editable: true,
          renderCell : (params) => (
            <Button
              variant="contained"
              color="primary"
              size="small"
              style={{marginLeft:16}}
              onClick={(e) => {creatorOk(e, params)}}
            >승인</Button>
          )
        },
        {
          field: 'button2',
          headerName: '거절',
          type: 'button',
          width: 120,
          editable: true,
          renderCell : (params) => (
            <Button
              variant="contained"
              color="primary"
              size="small"
              style={{marginLeft:16}}
              onClick={(e) => {creatorNo(e, params)}}
            >거절</Button>
          )
        },
    ];

    //심사승인
    function changeConfirm(id) {
      console.log("메소드 실행잘됨")
      fetch('http://localhost:8081/admin/creatorOK/'+id)
      .then(res => res.json())
      .then((res) => {
        console.log(res)
        if(!res.status==200){
              console.log("혹시 여기왔니?")
              throw new Error('http 오류');
        }
      });
    }

    //심사 거절
    function changereject(id) {
      console.log("메소드 실행잘됨")
      fetch('http://localhost:8081/admin/creatorNo/'+id)
      .then(res => res.json())
      .then((res) => {
        console.log(res)
        if(!res.status==200){
              console.log("혹시 여기왔니?")
              throw new Error('http 오류');
        }
      });
    }

    //심사 전체
    useEffect(() => {
        fetch('http://localhost:8081/admin/inspection')
        .then(res => res.json())
        .then((res) => {
          console.log("아래")
          console.log(res)
          console.log("위")
          if(!res.status==200){
                console.log("혹시 여기왔니?")
                throw new Error('http 오류');
              }
              setRows(createData(res));
               if (res.success) {
          }
        })
      }, []);
    return (
        <div>
             <MenuAppBar></MenuAppBar>
             <div style={{ height: 800, width: '100%' }}>
            <h2>크리에이터 심사</h2>
             <DataGrid
                rows={rows}
                columns={columns}
                pageSize={10}
                checkboxSelection
                disableSelectionOnClick
                />
            </div>
        </div>
    )

}