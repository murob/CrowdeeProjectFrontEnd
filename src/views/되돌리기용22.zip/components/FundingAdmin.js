import * as React from 'react';
import { DataGrid } from '@material-ui/data-grid';
import MenuAppBar from './MenuAppBar';
import { useEffect, useState } from "react";
import GetData from './GetData';
// import React, { useEffect } from 'react';

// const rows = [
//   {id : '12', password: 'fdf1' ,
//                          userName:'fdf2',nickName:'fdf3',
//                          mobile:'fdf4',  email:'fdf5', 
//                          emailCert:'fdf6', registDate:'fdf7', 
//                          secessionDate:'fdf8', userState:'fdf9',
//                          authorities:'fdf10'}
// ];

function createData(list) {
  var tempList = []
  for(var i in list){
    // console.log(list[i].nickName)
    // tempList.push({id : list[i].memberId, password : list[i].nickName,
    //               userName : list[i].nickName, nickNamee : list[i].nickName,
    //               mobile : list[i].nickName,  email : list[i].nickName, 
    //               emailCert : list[i].nickName, registDate : list[i].nickName, 
    //               secessionDate : list[i].nickName, userState : list[i].nickName,
    //               authorities : list[i].nickName});
    tempList.push({id:list[i].funding_id,password:list[i].funding_id, 
      userName: list[i].category, nickName: list[i].goalFundraising, mobile :list[i].restDate, 
      email: list[i].title})
  }
  console.log(tempList[1])
  return tempList;
}

const columns = [
    { field: 'Id', headerName: 'Id', width: 90 },
    {
      field: 'password',
      headerName: 'password',
      width: 140,
      type: 'text',
      editable: true,
    },
    {
      field: 'userName',
      headerName: 'userName',
      width: 150,
      type: 'text',
      editable: true,
    },
    {
      field: 'nickNamee',
      headerName: 'nickNamee',
      width: 150,
      type: 'text',
      editable: true,
    },
    {
      field: 'mobile',
      headerName: 'mobile',
      type: 'text',
      description: 'This column has a value getter and is not sortable.',
      sortable: false,
      width: 140,
    //   valueGetter: (params) =>
    //     `${params.getValue(params.id, 'firstName') || ''} ${
    //       params.getValue(params.id, 'lastName') || ''
    //     }`,
    },
    {
        field: 'email',
        headerName: 'email',
        type: 'text',
        width: 120,
        editable: true,
      },
      {
        field: 'emailCert',
        headerName: 'emailCert',
        type: 'text',
        width: 140,
        editable: true,
      },
      {
        field: 'registDate',
        headerName: 'registDate',
        type: 'text',
        width: 150,
        editable: true,
      },
      {
        field: 'secessionDate',
        headerName: 'secessionDate',
        type: 'text',
        width: 160,
        editable: true,
      },
      {
        field: 'userState',
        headerName: 'userState',
        type: 'text',
        width: 140,
        editable: true,
      },
      {
        field: 'authorities',
        headerName: 'authorities',
        type: 'text',
        width: 150,
        editable: true,
      },
  ];
 // { id: 1, lastName: 'Snow', firstName: 'Jon', age: 35 },
  export default function MemberAdmin() {
        const [rows,setRows] = React.useState([])
        // const [members, setMembers] = React.useState([])
    // setRows([{id : '12', password: 'fdf1' ,
    // userName:'fdf2',nickName:'fdf3',
    // mobile:'fdf4',  email:'fdf5', 
    // emailCert:'fdf6', registDate:'fdf7', 
    // secessionDate:'fdf8', userState:'fdf9',
    // authorities:'fdf10'}]);

    //여기 나중에 주석 해제하기!!!!!!!!!!
    useEffect(() => {
        fetch('http://localhost:8081/contents')
        .then(res => res.json())
        .then((res) => {
          console.log("아래")
          console.log(res)
          if(!res.status==200){
                console.log("혹시 여기왔니?")
                throw new Error('http 오류');
              }
              setRows(createData(res));
            // rows.push(createData(res[i].funding_id, res[i].category, res[i].goalFundraising, res[i].restDate, res[i].title, res[i].summery));
               if (res.success) {
          }
        })
      }, []);
    // useEffect(() => {
    //     fetch('http://localhost:8081/contents')
    //     .then(res => res.json())
    //     .then((res) => {
    //       console.log("아래")
    //       console.log(res)
    //       setRows(createData(res));
    //         // rows.push(createData(res[i].funding_id, res[i].category, res[i].goalFundraising, res[i].restDate, res[i].title, res[i].summery));
    //            if (res.success) {
    //       }
    //     })
    //   }, []);
    // const [rows,setRows] = React.useState([])
    // function createData(list) {
    //     var tempList = []
    //     for(var i in list){
    //       tempList.push({funding:list[i].funding_id,calories:list[i].funding_id, carbs: list[i].category, fat: list[i].goalFundraising, protein :list[i].restDate, name: list[i].title})
    //     }
    //     return tempList;
    //   }
// {id: props.memberId, password:props.password ,

// }
//         // userName:props.userName,nickName:props.nickName,
// mobile:props.mobile,  email:props.email, 
// emailCert:props.emailCert, registDate:props.registDate, 
// secessionDate:props.secessionDate, userState:props.userState,
// authorities:props.authorities,}
    return (
        <div>
            
             <MenuAppBar></MenuAppBar>
             <div style={{ height: 800, width: '100%' }}>
             <DataGrid
                rows={rows}
                columns={columns}
                pageSize={10}
                checkboxSelection
                disableSelectionOnClick
                />
            </div>
            
        
        </div>
    )

}